ESP WiFi Router UI Styler

Install:
1. Extract this ZIP.
2. Open chrome://extensions in Chrome.
3. Turn on Developer mode.
4. Click Load unpacked.
5. Select the extracted esp-wifi-router-styler folder.
6. Open or refresh http://192.168.68.105/

This extension only changes the appearance of the page in your browser.
It does not change the ESP8266 firmware, form parameters, or network settings.

If your device uses a different IP address, update the matches entry in manifest.json
to match that address, then reload the extension at chrome://extensions.

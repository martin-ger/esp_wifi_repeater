(() => {
  // Add a class so the extension styles only this device's configuration page.
  document.documentElement.classList.add("esp-router-styled");

  const heading = document.querySelector("h1");
  if (heading) {
    heading.textContent = "ESP WiFi NAT Router";
    heading.insertAdjacentHTML(
      "afterend",
      '<p class="esp-subtitle">Wireless network configuration and device management</p>'
    );
  }

  // Improve field labels without changing form names, values, or submission behavior.
  document.querySelectorAll("form").forEach((form, index) => {
    form.classList.add("esp-form");
    const title = form.querySelector("h2");
    if (title) title.classList.add("esp-section-title");
  });

  document.querySelectorAll("input:not([type=submit]):not([type=checkbox])").forEach(input => {
    input.classList.add("esp-input");
    if (input.type === "password") input.autocomplete = "new-password";
  });

  document.querySelectorAll('input[type="submit"]').forEach(button => {
    button.classList.add("esp-button");
  });

  document.querySelectorAll('input[type="checkbox"]').forEach(input => {
    input.classList.add("esp-checkbox");
  });

  // Mark the page's existing submit actions for consistent visual styling.
  document.querySelectorAll("h2").forEach((heading, index) => {
    heading.classList.add("esp-section-title");
    const next = heading.nextElementSibling;
    if (next && next.tagName === "FORM") next.classList.add("esp-form");
  });

  // Add a small footer without interfering with device requests.
  if (document.body && !document.querySelector(".esp-footer")) {
    const footer = document.createElement("div");
    footer.className = "esp-footer";
    footer.textContent = "ESP WiFi NAT Router • Local device interface";
    document.body.appendChild(footer);
  }
})();